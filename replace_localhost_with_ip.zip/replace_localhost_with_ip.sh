#!/usr/bin/env bash
set -euo pipefail

# Get the directory of the script (same as test.txt)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Get external IP (GCP metadata or public IP fallback)
EXTERNAL_IP=$(curl -fs -H "Metadata-Flavor: Google" \
  http://metadata.google.internal/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip || true)

if [[ -z "$EXTERNAL_IP" ]]; then
  EXTERNAL_IP=$(curl -s https://api.ipify.org)
fi

if [[ -z "$EXTERNAL_IP" ]]; then
  echo "[ERROR] Could not determine external IP."
  exit 1
fi

echo "[INFO] Replacing ALL '27.107.76.6' with '$EXTERNAL_IP' in $SCRIPT_DIR ..."

# Replace '27.107.76.6' with external IP in all text files (excluding common dirs)
grep -rl "27.107.76.6" "$SCRIPT_DIR" --exclude-dir={node_modules,venv,.git} | while read -r file; do
  echo "↪ Updating $file"
  sed -i "s|27.107.76.6|$EXTERNAL_IP|g" "$file"
done

echo "[INFO] All done."
