# This file makes postgres_utility a Python package.
