import configparser
import urllib.parse
from google.cloud.sql.connector import Connector
import os
import sqlalchemy

def get_db_url_and_schema():
    config = configparser.ConfigParser()
    config_path = os.path.abspath('./config/config.ini')
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found at: {config_path}")
    config.read(config_path)
    
    section = 'postgres_db'
    project_id = config.get(section, 'project_id')
    region = config.get(section, 'region')
    instance_name = config.get(section, 'instance_name')
    database = config.get(section, 'database')
    iam_user = config.get(section, 'iam_user')
    schema = config.get(section, 'schema')
    input_dir = config.get('extraction_utility', 'data_output_directory')
    ip_type = "private"
    
    instance_connection_name = f"{project_id}:{region}:{instance_name}"
    return instance_connection_name, database, iam_user, schema, input_dir, ip_type

def get_instance_id():
    config = configparser.ConfigParser()
    config_path = os.path.abspath('./config/config.ini')
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found at: {config_path}")
    config.read(config_path)
    
    section = 'postgres_db'
    instance_id = config.get(section, 'instance_name')
    
    return instance_id
