#!/bin/bash

echo "[INFO] Getting internal IP..."
EXTERNAL_IP=$(hostname -I | awk '{print $1}')
if [[ -z "$EXTERNAL_IP" ]]; then
    echo "[ERROR] Could not get IP address!"
    exit 1
fi

echo "[INFO] Using internal IP: $EXTERNAL_IP"

ROOT_DIR=$(pwd)
LOG_FILE="$ROOT_DIR/replacement.log"
> "$LOG_FILE"

echo "[INFO] Scanning folder: $ROOT_DIR"
echo "[INFO] Logging to: $LOG_FILE"

# Define patterns to replace
declare -a PATTERNS=("http://localhost" "https://localhost" "http://127.0.0.1" "https://127.0.0.1")

# Loop over files
find "$ROOT_DIR" -type f \( ! -name "$(basename "$0")" \) | while read -r file; do
    UPDATED=false
    for pattern in "${PATTERNS[@]}"; do
        if grep -q "$pattern" "$file"; then
            UPDATED=true
            sed -i "s|$pattern|http://$EXTERNAL_IP|g" "$file"
        fi
    done

    if [ "$UPDATED" = true ]; then
        echo "[UPDATED] $file" >> "$LOG_FILE"
    fi
done

echo "[✅ DONE] See log at: $LOG_FILE"
