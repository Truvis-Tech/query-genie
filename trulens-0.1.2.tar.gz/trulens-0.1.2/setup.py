from setuptools import setup, find_packages

setup(
    name='trulens',
    version='0.1.2',
    description='Trulens backend',
    author='TruVis',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    install_requires=[
        # Will be auto-populated by requirements.txt during build or you can list manually
    ],
    include_package_data=True,  # No need to include config files
    zip_safe=False,
    entry_points={
        'console_scripts': [
            'trulens-app = run:main'
        ]
    },
)
