import logging
import sys


logger = logging.getLogger("app_logger")
logger.setLevel(logging.INFO)

log_handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter(
    '%(asctime)s - %(levelname)s - %(message)s'
)
log_handler.setFormatter(formatter)
logger.addHandler(log_handler)
