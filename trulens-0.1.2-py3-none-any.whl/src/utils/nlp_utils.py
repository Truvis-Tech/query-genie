import nltk

english_vocab = set(w.lower() for w in nltk.corpus.words.words())

def invalid_utterance_in_prompt(nlp_query):
    invalid_utterances = ['hi', 'hello', "hey", "good morning", "morning", "good", "how are you?", "how are you", "how is it going", ""]
    query_lowercased = nlp_query.lower()
    return query_lowercased in invalid_utterances

def validate_english(nlp_query):
    query_words = nlp_query.split(" ")
    validity = query_words[0].lower()
    return validity not in english_vocab

def check_for_modification_in_query(sql_query: str):
    return "DELETE" in sql_query.upper().split(" ") or "TRUNCATE" in sql_query.upper().split(" ") or "UPDATE" in sql_query.upper().split(" ")