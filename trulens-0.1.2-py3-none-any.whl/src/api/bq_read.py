from fastapi import HTTPException, APIRouter
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import os

from src.services.bq_client import get_bigquery_client
from src.utils.logger import logger

bq_router = APIRouter()

class TableRequest(BaseModel):
    market: str

@bq_router.post("/get-tables")
def get_tables(payload: TableRequest):
    logger.info("GET_TABLES request received for market: %s", payload.market)
    if os.getenv("TEST_MODE") == "true":
        return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200)
    try:
        client, project_id, dataset_id = get_bigquery_client(payload.market)
        query = f"""
            SELECT table_name
            FROM `{project_id}.{dataset_id}.INFORMATION_SCHEMA.TABLES`
            WHERE table_type = 'BASE TABLE'
            ORDER BY table_name
        """
        logger.debug("Executing SQL query: %s", query.strip())
        result = client.query(query).result()
        tables = [row["table_name"] for row in result]
        logger.info("Retrieved %d tables", len(tables))

        return JSONResponse(
            status_code=200,
            content={'result': tables, 'metadata': "", 'sql_query': "", 'textual_summary': [], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
        )
    except FileNotFoundError as e:
        logger.error("Credentials not found: %s", e)
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error("GET_TABLES failed: %s", e)
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")
    
class ColumnRequest(BaseModel):
    market: str
    table_name: str

class SimpleDataRequest(BaseModel):
    market: str

@bq_router.post("/get-columns")
def get_columns(payload: ColumnRequest):
    logger.info("GET_COLUMNS request for %s.%s", payload.market, payload.table_name)
    if os.getenv("TEST_MODE") == "true":
        return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200)
    try:
        client, project_id, dataset_id = get_bigquery_client(payload.market)
        query = f"""
            SELECT column_name
            FROM `{project_id}.{dataset_id}.INFORMATION_SCHEMA.COLUMNS`
            WHERE table_name = '{payload.table_name}'
            ORDER BY ordinal_position
        """
        logger.debug("Executing SQL query: %s", query.strip())
        result = client.query(query).result()
        columns = [row["column_name"] for row in result]
        logger.info("Retrieved %d columns", len(columns))

        return JSONResponse(
            status_code=200,
            content={'result': columns, 'metadata': "", 'sql_query': "", 'textual_summary': [], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
        )
    except FileNotFoundError as e:
        logger.error("Credentials not found: %s", e)
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error("GET_COLUMNS failed: %s", e)
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")



@bq_router.post("/fetch-data/")
def fetch_data(payload: SimpleDataRequest):
    # Custom connection details for BigQuery
    # job_config = bigquery.QueryJobConfig(default_dataset=RECOM_BQ_PROJECT + "." + RECOM_BQ_DATASET)
    # credentials = service_account.Credentials.from_service_account_file(
    #     RECOM_BQ_SERVICE_ACCOUNT_FILE_PATH
    # )
    # bq = bigquery.Client(credentials=credentials, project=RECOM_BQ_PROJECT)
    client, project_id, dataset_id = get_bigquery_client(payload.market)
    query = f"""
            SELECT * FROM `{project_id}.{dataset_id}.rulemaster` AS RM
                              INNER JOIN `{project_id}.{dataset_id}.recommendation` AS RE
                                         ON RM.rule_id = RE.rule_id \
            """
    query_job = client.query(query)
    results = query_job.result()

    data = [dict(row.items()) for row in results]
    return {"data": data}

@bq_router.post("/fetch-count/schema")
def fetch_count_schema(payload: SimpleDataRequest):
    client, project_id, dataset_id = get_bigquery_client(payload.market)
    query = f"""
            SELECT SUM(no_of_schemas) AS total_schemas
            FROM `{project_id}.{dataset_id}.recommendation` \
            """
    query_job = client.query(query)
    results = query_job.result()
    data = [dict(row.items()) for row in results]
    return {"data": data}

@bq_router.post("/fetch-count/queries")
def fetch_count_queries(payload: SimpleDataRequest):
    # Custom connection details for BigQuery
    client, project_id, dataset_id = get_bigquery_client(payload.market)
    query = f"""
            SELECT SUM(no_of_queries) AS total_schemas
            FROM `{project_id}.{dataset_id}.recommendation` \
            """
    query_job = client.query(query)
    results = query_job.result()
    data = [dict(row.items()) for row in results]
    return {"data": data}

@bq_router.post("/fetch-count/total_scanned")
def fetch_count_total(payload: SimpleDataRequest):
    # Custom connection details for BigQuery
    client, project_id, dataset_id = get_bigquery_client(payload.market)
    query = f"""
            SELECT total_query_scanned AS total_query_scanned
            FROM `{project_id}.{dataset_id}.recommendation`
                     LIMIT 1 \
            """
    query_job = client.query(query)
    results = query_job.result()
    data = [dict(row.items()) for row in results]
    return {"data": data}