from fastapi import HTTPException, APIRouter
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import psycopg2
from fastapi.encoders import jsonable_encoder
import os

from src.database.db_connector import get_postgres_connection_params
from src.utils.config_reader import load_config
from src.database.postgres_loader import generate_id_key, generate_column_id_key
from src.utils.logger import logger

pg_router = APIRouter()

class TableMetadataRequest(BaseModel):
    market: str
    table_name: str

@pg_router.post("/get-table-metadata")
def get_metadata(payload: TableMetadataRequest):
    logger.info("Fetching metadata for table: %s", payload.table_name)
    if os.getenv("TEST_MODE") == "true":
        return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200)
    market = payload.market
    table = payload.table_name
    host, port, database, user, password = get_postgres_connection_params(market)
    config = load_config(market)
    BIGQUERY_PROJECT_ID = config.get('Database', 'bigquery_project')
    BIGQUERY_DATASET_ID = config.get('Database', 'bigquery_dataset')

    id_key = generate_id_key(BIGQUERY_PROJECT_ID, BIGQUERY_DATASET_ID, table)

    try:
        conn = psycopg2.connect(
                host=host,
                port=port,
                dbname=database,
                user=user,
                password=password
            )
        cur = conn.cursor()
        cur.execute("SELECT * FROM table_config WHERE id_key = %s", (id_key,))
        row = cur.fetchone()
        if row:
            colnames = [desc[0] for desc in cur.description]
            table_meta = jsonable_encoder(dict(zip(colnames, row)))
        else:
            raise HTTPException(
                status_code=404,
                detail="Table metadata not found."
            )

        if not table_meta:
            raise HTTPException(
                status_code=404,
                detail = "Table metadata not found."
            )
        logger.debug("Fetched metadata for %s", id_key)
        return JSONResponse(
            status_code=200,
            content={'result': table_meta, 'metadata': "", 'sql_query': "", 'textual_summary': [], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
        )
    except Exception as e:
        logger.error("Metadata fetch failed: %s", e)
        raise HTTPException(
            status_code=400,
            detail=str(e)
        )
    finally:
         if conn:
              cur.close()
              conn.close()

class ColumnMetadataRequest(BaseModel):
    market: str
    table_name: str
    column_name: str

@pg_router.post("/get-column-metadata")
def get_metadata(payload: ColumnMetadataRequest):
    logger.info("Fetching column metadata for %s.%s", payload.table_name, payload.column_name)
    if os.getenv("TEST_MODE") == "true":
        return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200)
    market = payload.market
    table = payload.table_name
    column = payload.column_name
    host, port, database, user, password = get_postgres_connection_params(market)
    config = load_config(market)
    BIGQUERY_PROJECT_ID = config.get('Database', 'bigquery_project')
    BIGQUERY_DATASET_ID = config.get('Database', 'bigquery_dataset')

    id_key = generate_column_id_key(BIGQUERY_PROJECT_ID, BIGQUERY_DATASET_ID, table, column)

    try:
        conn = psycopg2.connect(
                host=host,
                port=port,
                dbname=database,
                user=user,
                password=password
            )
        cur = conn.cursor()
        cur.execute("SELECT * FROM column_config WHERE id_key = %s", (id_key,))
        row = cur.fetchone()
        if row:
            colnames = [desc[0] for desc in cur.description]
            column_meta = jsonable_encoder(dict(zip(colnames, row)))
        else:
            raise HTTPException(
                status_code=404,
                detail="Column metadata not found."
            )

        if not column_meta:
            raise HTTPException(
                status_code=404,
                detail = "Column metadata not found."
            )
        logger.debug("Fetched column metadata for %s", id_key)
        return JSONResponse(
            status_code=200,
            content={'result': column_meta, 'metadata': "", 'sql_query': "", 'textual_summary': [], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
        )
    except Exception as e:
        logger.error("Column metadata fetch failed: %s", e)
        raise HTTPException(
            status_code=400,
            detail=str(e)
        )
    finally:
         if conn:
              cur.close()
              conn.close()