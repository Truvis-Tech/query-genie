import warnings
import json
import os
import re
import nltk
import httpx
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse, HTMLResponse
from pydantic import BaseModel
from langchain_community.document_loaders import JSONLoader

from src.services.optimise_query import OptimiseQuery
from src.utils.config_reader import load_config
from src.utils.nlp_utils import *
from src.services.guardrails_service import *
from src.services.text_to_sql_service import ConvertTextToSqlRequest
from src.database.query_executor import execute
from src.database.postgres_loader import PostgresLoader
from src.services.cost_estimator import Estimate
from src.utils.logger import logger
from typing import Dict, Any


nltk.download('punkt')
nltk.download('words')
english_vocab = set(w.lower() for w in nltk.corpus.words.words())

router = APIRouter()

warnings.filterwarnings("ignore")

# Custom HTTP client
custom_http_client = httpx.Client(verify=False)

def remove_numbers_and_dots(s: str) -> str:
    return re.sub(r'[\d\.]+', '', s)

class QueryRequest(BaseModel):
    query: str
    llm_type: str
    market: str

class InsightPayload(BaseModel):
    data: dict
    user_prompt: str
    market: str

@router.get("/health")
async def health():
    return "Welcome to TruLens"

@router.get("/")
async def index():
    return HTMLResponse("<h1>Welcome to TruLens</h1>")

@router.post("/generate_query")
async def generate_query(req: QueryRequest):
    logger.info("GENERATE_QUERY: '%s'", req.query)
    if os.getenv("TEST_MODE") == "true":
        return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200) 
    try:
        query = req.query
        llm_type = 'openai'  # override to enforce OpenAI
        market = req.market
        config = load_config(market)
        logger.debug("Validating query input...")
        if invalid_utterance_in_prompt(query):
            logger.warning("Invalid BI query detected")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["Sorry not a valid BI query. Could you please try again?"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )

        if validate_english(query):
            logger.warning("Query failed English validation")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["Sorry I didn't get you. Could you please try again?"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )

        validation_res = validate_query_intent_for_analytical(query, config)
        if validation_res == 'False':
            logger.warning("Query not identified as analytical")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["Sorry not a valid BI query. Could you please try again?"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )

        request = ConvertTextToSqlRequest(query, llm_type, config)
        sql_query = request.convert_text_to_sql_using_llm()
        logger.info("Generated SQL: %s", sql_query) 

        if check_for_modification_in_query(sql_query=sql_query):
            logger.warning("Modification detected in SQL query.")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["Action not allowed. Are you trying to UPDATE/DELETE/TRUNCATE data?"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )

        if validate_query_for_sql_injection(sql_query, config) == 'True':
            logger.warning("SQL Injection detected.")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["SQL Injection detected in the Query. Query execution blocked by guardrails !!"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )

        ans = {'sql_query_generated': sql_query}
        return JSONResponse(content=ans)
    except Exception as e:
        logger.exception("Query generation error")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

class QueryPayload(BaseModel):
    query: str
    market: str

@router.post("/execute_query")
def execute_query(payload: QueryPayload):
    logger.info("EXECUTE_QUERY: '%s'", payload.query)
    if os.getenv("TEST_MODE") == "true":
        return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200) 
    try:
        result = execute(payload.query, payload.market)
        logger.info("Executed Query result: %s", result)
        return JSONResponse(
            status_code=200,
            content={'result': result, 'metadata': "", 'sql_query': "", 'textual_summary': [""], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
        )
        # return result
    except Exception as e:
        logger.exception("Query execution error")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

class MetadataRequest(BaseModel):
    metadata_type: str  # "table" or "column"
    market: str

@router.post("/postgres_loader/")
async def postgres_loader(request: MetadataRequest):
    logger.info("LOAD_METADATA: %s", request.metadata_type)
    if os.getenv("TEST_MODE") == "true":
        return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200)
    try:
        config = load_config(request.market)
        DB_TABLES_PATH = config.get('Database', 'tables_path')
        DB_COLUMN_PATH = config.get('Database', 'columns_path')
        config = load_config(request.market)

        project_id = config.get('Database', 'bigquery_project')
        dataset_id = config.get('Database', 'bigquery_dataset')

        postgres_loader = PostgresLoader(request.market)
        if request.metadata_type == "table":
            postgres_loader.create_table_config()
            data = JSONLoader(
                file_path=DB_TABLES_PATH,
                jq_schema='.[]',
                text_content=False,
                json_lines=False
            ).load()

            for doc in data:
                record = json.loads(doc.page_content)
                record['data_source_id'] = project_id
                record['data_namespace'] = dataset_id
                postgres_loader.insert_table_metadata(record, "table_config")

            logger.info("Loaded %s metadata", request.metadata_type)
            return {"status": "success", "message": "table_config metadata inserted successfully"}

        elif request.metadata_type == "column":
            postgres_loader.create_column_config()
            data = JSONLoader(
                file_path=DB_COLUMN_PATH,
                jq_schema='.[]',
                text_content=False,
                json_lines=False
            ).load()

            for doc in data:
                record = json.loads(doc.page_content)
                record['data_source_id'] = project_id
                record['data_namespace'] = dataset_id
                postgres_loader.insert_column_metadata(record, "column_config")

            logger.info("Loaded %s metadata", request.metadata_type)
            return {"status": "success", "message": "column_config metadata inserted successfully"}

        else:
            logger.error("Metadata load failed: Invalid metadata_type")
            raise HTTPException(
                status_code=400,
                detail="Invalid metadata_type. Must be 'table' or 'column'."
            )

    except Exception as e:
        logger.error("Metadata load failed: %s", e)
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error: {str(e)}"
        )

@router.post("/estimate")
def estimate_cost(payload: QueryPayload):
    logger.info("ESTIMATE_QUERY_COST: '%s'", payload.query)
    if os.getenv("TEST_MODE") == "true":
        return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200)
    try:
        estimate = Estimate(payload.query, payload.market)
        result = estimate.estimate_query_cost()

        if result.get("status") == "error":
            raise HTTPException(status_code=400, detail=result["error_message"])
        logger.info("Query cost estimated: %s", result)
        return result

    except Exception as e:
        logger.error("Error estimating cost")
        raise HTTPException(status_code=500, detail=f"Unexpected server error: {str(e)}")

@router.post("/generate_insights")
async def generate_insights(payload: InsightPayload):
    """
    Generate insights from the given data and user query using LLM.

    Args:
        payload (InsightPayload): Contains:
            - query (str): The original user query
            - data (dict): The query result data containing 'result' key with the data

    Returns:
        JSONResponse: Contains generated insights or error message
    """
    logger.info("GENERATE_INSIGHTS: Processing request")

    try:
        # Extract data and query from payload
        data = payload.data
        user_query = payload.user_prompt

        if not data or "result" not in data:
            logger.warning("Invalid data format: missing 'result' key")
            return JSONResponse(
                status_code=400,
                content={"error": "Invalid data format: must contain 'result' key"}
            )

        result_data = data["result"]
        if not result_data:
            return JSONResponse(
                status_code=200,
                content={"insights": "No data available to generate insights from."}
            )

        # Get the LLM prompt for generating insights
        from src.llm.prompt_templates import get_prompt_for_insights
        from src.llm.llm_connector import LLMConnector
        from src.utils.config_reader import load_config

        # Convert the result data to a string for the prompt
        data_str = json.dumps(result_data, indent=2)

        # Get the prompt
        prompt_text = get_prompt_for_insights(data_str, user_query)

        # Prepare messages for the LLM
        messages = [
            {"role": "system", "content": "You are a helpful assistant that provides data insights and analysis."},
            {"role": "user", "content": prompt_text}
        ]

        # Get config for LLM settings
        config = load_config(payload.market)  # You might need to pass the market parameter if needed

        try:
            # Initialize LLM connector and get response
            llm_connector = LLMConnector(messages, config)
            insights = llm_connector.get_llm_response()

            logger.info("Successfully generated insights")
            return JSONResponse(
                status_code=200,
                content={"insights": insights}
            )

        except Exception as llm_error:
            logger.error(f"Error from LLM service: {str(llm_error)}")
            # Fallback to a simple response if LLM fails
            return JSONResponse(
                status_code=200,
                content={"insights": f"Based on the query results: {data_str}"}
            )

    except Exception as e:
        logger.error(f"Error generating insights: {str(e)}", exc_info=True)
        return JSONResponse(
            status_code=500,
            content={"error": f"Failed to generate insights: {str(e)}"}
        )

@router.post("/optimise_query")
async def optimise_query(req: QueryRequest):
    logger.info("OPTIMISE_QUERY: '%s'", req.query)
    if os.getenv("TEST_MODE") == "true":
        return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200)
    try:
        query = req.query
        llm_type = 'openai'  # override to enforce OpenAI
        market = req.market
        config = load_config(market)
        logger.debug("Validating query input...")
        if invalid_utterance_in_prompt(query):
            logger.warning("Invalid BI query detected")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["Sorry not a valid BI query. Could you please try again?"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )

        if check_for_modification_in_query(sql_query=query):
            logger.warning("Modification detected in SQL query.")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["Action not allowed. Are you trying to UPDATE/DELETE/TRUNCATE data?"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )

        if validate_query_for_sql_injection(query, config) == 'True':
            logger.warning("SQL Injection detected.")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["SQL Injection detected in the Query. Query execution blocked by guardrails !!"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )
        request = OptimiseQuery(query, llm_type, config)
        sql_query = request.optimise_query()
        logger.info("Generated SQL: %s", sql_query)

        if check_for_modification_in_query(sql_query=sql_query):
            logger.warning("Modification detected in SQL query.")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["Action not allowed. Are you trying to UPDATE/DELETE/TRUNCATE data?"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )

        if validate_query_for_sql_injection(sql_query, config) == 'True':
            logger.warning("SQL Injection detected.")
            return JSONResponse(
                status_code=400,
                content={'result': [], 'metadata': "", 'sql_query': "", 'textual_summary': ["SQL Injection detected in the Query. Query execution blocked by guardrails !!"], 'followup_prompts': [], "x-axis": "", "typeOFgraph": ""}
            )

        ans = {'sql_query_generated': sql_query}
        return JSONResponse(content=ans)
    except Exception as e:
        logger.exception("Query generation error")
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")
# @router.post("/postgres_loader/")
# async def postgres_loader(request: MetadataRequest):
#     logger.info("LOAD_METADATA: %s", request.metadata_type)
#     if os.getenv("TEST_MODE") == "true":
#         return JSONResponse(content={"message": "Mocked response in test mode"}, status_code=200)
    
#     try:
#         config = load_config(request.market)
#         market_config_dir = os.path.join("config", request.market)
#         DB_TABLES_DIR = os.path.join(market_config_dir, "tables")
#         DB_COLUMNS_DIR = os.path.join(market_config_dir, "columns")

#         project_id = config.get('Database', 'bigquery_project')
#         dataset_id = config.get('Database', 'bigquery_dataset')

#         postgres_loader = PostgresLoader(request.market)

#         if request.metadata_type == "table":
#             postgres_loader.create_table_config()
#             for filename in os.listdir(DB_TABLES_DIR):
#                 if filename.endswith(".json"):
#                     filepath = os.path.join(DB_TABLES_DIR, filename)
#                     data = JSONLoader(
#                         file_path=filepath,
#                         jq_schema='.',
#                         text_content=False,
#                         json_lines=False
#                     ).load()

#                     for doc in data:
#                         record = json.loads(doc.page_content)
#                         record['data_source_id'] = project_id
#                         record['data_namespace'] = dataset_id
#                         postgres_loader.insert_table_metadata(record, "table_config")

#             logger.info("Loaded %s metadata", request.metadata_type)
#             return {"status": "success", "message": "table_config metadata inserted successfully"}

#         elif request.metadata_type == "column":
#             postgres_loader.create_column_config()
#             for filename in os.listdir(DB_COLUMNS_DIR):
#                 if filename.endswith(".json"):
#                     filepath = os.path.join(DB_COLUMNS_DIR, filename)
#                     data = JSONLoader(
#                         file_path=filepath,
#                         jq_schema='.[]',
#                         text_content=False,
#                         json_lines=False
#                     ).load()

#                     for doc in data:
#                         record = json.loads(doc.page_content)
#                         record['data_source_id'] = project_id
#                         record['data_namespace'] = dataset_id
#                         postgres_loader.insert_column_metadata(record, "column_config")

#             logger.info("Loaded %s metadata", request.metadata_type)
#             return {"status": "success", "message": "column_config metadata inserted successfully"}

#         else:
#             logger.error("Metadata load failed: Invalid metadata_type")
#             raise HTTPException(
#                 status_code=400,
#                 detail="Invalid metadata_type. Must be 'table' or 'column'."
#             )