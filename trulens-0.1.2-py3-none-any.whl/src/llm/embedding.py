from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.embeddings import OpenAIEmbeddings
from src.utils.logger import logger

class Embedding():
    def __init__(self, config):
        self.config = config
        self.OPENAI_BASE_EMBEDDING_URL = self.config.get('OpenAI', 'base_embedding_url')
        self.OPENAI_PROJECT_ID = self.config.get('OpenAI', 'project_id')
        self.OPENAI_API_KEY = self.config.get('OpenAI', 'api_key')
        self.OPENAI_API_VERSION = self.config.get('OpenAI', 'api_version')
        self.OPENAI_EMBEDDING_MODEL = self.config.get('OpenAI', 'embedding_model')

    def get_embeddings(self):
        if self.OPENAI_BASE_EMBEDDING_URL:
            logger.info("Initializing embeddings")
            headers = {
                'HSBC-Params': f'{{"req_from":"{self.OPENAI_PROJECT_ID}", "type":"embedding"}}',
                'Authorization-Type': 'genai',
                'Authorization': f'Bearer {self.OPENAI_API_KEY}',
                'Content-Type': 'application/json'
            }
            embedding = AzureOpenAIEmbeddings(azure_endpoint=self.OPENAI_BASE_EMBEDDING_URL,
                                            openai_api_key=self.OPENAI_API_KEY,
                                            openai_api_version=self.OPENAI_API_VERSION,
                                            deployment=self.OPENAI_EMBEDDING_MODEL,
                                            default_headers=headers)
        else:
            embedding = OpenAIEmbeddings(
            model=self.OPENAI_EMBEDDING_MODEL,
            openai_api_key=self.OPENAI_API_KEY
            # With the `text-embedding-3` class
            # of models, you can specify the size
            # of the embeddings you want returned.
            # dimensions=1024
            )
        return embedding