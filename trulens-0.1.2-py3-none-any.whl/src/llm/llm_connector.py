import requests
import json
from openai import OpenAI

from src.utils.logger import logger

class LLMConnector:
    def __init__(self, messages_prompt, config):
        self.messages_prompt = messages_prompt
        self.config = config
        self.OPENAI_BASE_URL = self.config.get('OpenAI', 'base_url')
        self.OPENAI_PROJECT_ID = self.config.get('OpenAI', 'project_id')
        self.OPENAI_API_KEY = self.config.get('OpenAI', 'api_key')
        self.OPENAI_MODEL = self.config.get('OpenAI', 'model')

    def get_llm_response(self):
        
        # Initialize OpenAI client with or without base_url
        if self.OPENAI_BASE_URL:
            headers = {
                'HSBC-Params': f'{{"req_from":"{self.OPENAI_PROJECT_ID}", "type":"chat"}}',
                'Authorization-Type': 'genai',
                'Authorization': f'Bearer {self.OPENAI_API_KEY}',
                'Content-Type': 'application/json'
            }

            data = {
                "messages": self.messages_prompt,
                "temperature": 0.0 ,
                "top_p": 0.1,
                "frequency_penalty": 0.1,
                "presence_penalty": 0.1,
                "max_tokens": 2919,
                "stop": None,
                "stream": False
            }
            logger.info("LLM request to %s", self.OPENAI_MODEL)
            response = requests.post(self.OPENAI_BASE_URL , headers=headers, json=data, verify=False )
            response = json.loads(response.text)
            logger.debug("LLM response: %s", response)
            answer = response['choices'][0]['message']['content'].strip()

        else:
            client = OpenAI(api_key=self.OPENAI_API_KEY)
            response = client.chat.completions.create(
                model = self.OPENAI_MODEL,
                messages = self.messages_prompt,
                temperature = 0.0,
                top_p = 0.1,
                presence_penalty = 0.1,
                frequency_penalty = 0.1
            )
            answer = response.choices[0].message.content.strip()
            logger.info("LLM request to %s", self.OPENAI_MODEL)
            logger.debug("LLM response: %s", response)
        return answer