def get_prompt_for_analytical_intent(query: str):
    prompt = f'''Following query is the analytical query or not: 
                {query}
                Just print True or False and nothing else'''
    return prompt

def get_prompt_for_generating_sql_query(tables: str, schema: str, content: str):
    prompt = f'''
    ### Table Details
    The following are the table descriptions and join keys, separated by '|':
    
    TABLES: {tables}

    ### Column Schema
    Below are the matched table-column mappings, also separated by '|':

    MATCHED_SCHEMA: {schema}

    ### User Request
    Write a BigQuery SQL query that fulfills this requirement:

    {content}

    ### Rules and Guidelines (Follow all strictly)
    1. Use **only** column names listed in the MATCHED_SCHEMA section.
    2. Associate each column strictly with its corresponding table from MATCHED_SCHEMA.
    3. If the user prompt matches any known prompt examples, return the corresponding sample SQL query.
    4. Use `SAFE_DIVIDE`, `SAFE_CAST` where applicable.
    5. Avoid using aliases in `GROUP BY` and `ORDER BY`.
    6. Use `UNNEST` when dealing with STRUCT or ARRAY<STRUCT> fields.
    7. Ensure clean formatting and consistent indentation.
    8. Use `GROUP BY` if the query includes aggregation functions (e.g., `COUNT`).
    9. Do **not** include GCP project IDs or dataset references in the output.
    10. Optimize the query for performance:
        - Use efficient joins and indexed columns.
        - Avoid redundant calculations or unnecessary casting.
    11. Remove `CAST()` where not needed.
    12. Use BigQuery functions based on data type:
        - For timestamps, use `TIMESTAMP_SUB` or `DATE_ADD` with `INTERVAL ... DAY`.
        - Convert months to days using a 30-day month approximation.
    13. **Return format**:  
        `Optimised Query:-your_sql_query_here`  
        (No extra text or formatting before or after.)

    Respond with only the SQL query in the exact format above.

    '''
    return prompt

def get_prompt_verify_sql_injection(sql_query: str):
    prompt = f"""
        You are a cybersecurity expert specializing in SQL injection detection.  
        Analyze the given SQL query and determine if it **has SQL injection intent**.  

        **Rules for detection:**  
        - Query contains patterns like `OR 1=1`, `UNION SELECT`, `--`, `DROP TABLE`, etc.  
        - Use of **string concatenation** that modifies query logic dynamically.  
        - **Stacked queries** (`;` multiple statements in one query).  
        - **Unusual use of quotes or comments** that might escape intended query structure.  

        **Return only `True` or `False` (without any explanation):**  
        - **`True`** → If SQL injection risk is detected.  
        - **`False`** → If no SQL injection risk is detected.  

        **Analyze this SQL query and return only True or False:**
        {sql_query}
    """
    return prompt

def get_prompt_for_insights(data: str, query: str) -> str:
    """
    Generate a structured prompt for LLM to derive insights from data based on the user's query.
    
    Args:
        data (str): The data to analyze, typically in string format (can be JSON/dict/list)
        query (str): The original user query that generated this data
        
    Returns:
        str: A structured prompt for the LLM to generate insights
    """
    prompt = f"""
    # Data Analysis and Insight Generation
    
    ## Context
    You are a senior data analyst with expertise in identifying patterns, trends, and insights from data.
    Below is data generated in response to the user's query: "{query}"
    
    ## Data
    {data}
    
    ## Your Task
    Analyze this data and provide concise insights in bullet points for the following categories only:
    
    1. **Top Insights**
       - Identify 3-5 key findings from the data
       - Focus on the most significant patterns or trends
       - Include relevant statistics or metrics to support each insight
       - Present each insight as a clear, concise bullet point
    
    2. **Trend Analysis**
       - Identify any temporal patterns or directional movements in the data
       - Note the direction and magnitude of each trend
       - Compare current trends with historical context if available
       - Present each trend as a clear, concise bullet point
    
    3. **Anomaly Detection**
       - Identify any outliers or unusual data points
       - Briefly explain why each anomaly is significant
       - Rate the importance of each anomaly (high/medium/low)
       - Present each anomaly as a clear, concise bullet point
    
    ## Output Format
    - Use bullet points for all insights, trends, and anomalies
    - Include relevant numbers and metrics to support your points
    - Format large numbers appropriately (e.g., 1.2M instead of 1,200,000)
    - Keep the total response under 300 words
    
    ## Example Format
    ### Top Insights
    • [Insight 1 with supporting metrics]
    • [Insight 2 with supporting metrics]
    • [Insight 3 with supporting metrics]
    
    ### Trend Analysis
    • [Trend 1 with direction and magnitude]
    • [Trend 2 with direction and magnitude]
    
    ### Anomaly Detection
    • [Anomaly 1] - [Significance: High/Medium/Low]
    • [Anomaly 2] - [Significance: High/Medium/Low]
    
    Now, please analyze the provided data and generate your insights using only these three categories in bullet point format.
    """
    
    return prompt

def get_prompt_for_optimised_query(tables: str, schema: str, sql_query: str):
    prompt = f'''
    # BigQuery SQL Optimization Task

    ## Table Information
    ```
    {tables}
    ```

    ## Schema Information
    ```
    {schema}
    ```

    ## Original SQL Query
    ```sql
    {sql_query}
    ```

    ## Your Task
    Optimize the above BigQuery SQL query for better performance while maintaining identical functionality and output.

    ## Optimization Guidelines
    1. **Query Structure Improvements**:
       - Simplify complex subqueries or replace with more efficient alternatives
       - Optimize JOIN operations (consider JOIN order and type)
       - Reduce unnecessary calculations and redundant operations
       - Improve WHERE clause filtering to leverage indexes
       - Optimize GROUP BY operations

    2. **BigQuery-Specific Optimizations**:
       - Use appropriate partitioning and clustering when referenced in the query
       - Minimize data shuffling across nodes
       - Reduce the amount of data processed (column pruning, early filtering)
       - Use BigQuery's materialized views pattern where applicable
       - Apply appropriate BigQuery-specific functions for better performance

    3. **Data Type Handling**:
       - Use SAFE_DIVIDE and SAFE_CAST where appropriate for error prevention
       - Remove unnecessary CAST operations when possible
       - Use appropriate data type functions (e.g., TIMESTAMP_SUB only for TIMESTAMP data type)
       - When using TIMESTAMP_SUB with months, convert to days (1 month = 30 days)

    4. **Code Quality**:
       - Ensure consistent spacing and correct formatting
       - Avoid using aliases in GROUP BY and ORDER BY clauses
       - Use UNNEST for Struct Datatype or Struct Array Datatype fields when needed
       - Remove GCP Project ID and Dataset references in the output SQL

    ## Important Constraints
    - Use ONLY column names mentioned in the provided schema
    - Associate column names only with the table names specified in the schema
    - If there is no meaningful optimization opportunity, return the original query unchanged
    - Always format your response exactly as: "Optimised Query:-[your optimized query]"
    - Do not include any explanations or comments in your response

    ## Performance Focus Areas
    - Query cost reduction
    - Execution time improvement
    - Resource utilization optimization
    - Scalability for large datasets
    '''
    return prompt