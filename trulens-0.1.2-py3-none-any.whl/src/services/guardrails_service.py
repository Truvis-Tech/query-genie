from src.llm.prompt_templates import get_prompt_for_analytical_intent, get_prompt_verify_sql_injection
from src.llm.llm_connector import *

def validate_query_intent_for_analytical(user_query, config):
    logger.debug("Validating query intent")
    prompt = get_prompt_for_analytical_intent(user_query)
    messages = [{"role": "user", "content": f"{prompt}"}]
    res = LLMConnector(messages, config)
    return res

def validate_query_for_sql_injection(sql_query: str, config):
    logger.debug("Checking for SQLi")
    prompt = get_prompt_verify_sql_injection(sql_query=sql_query)
    messages = [{"role": "user", "content": f"{prompt}"}]
    res = LLMConnector(messages, config)
    return res