"""
BigQuery cost estimation functions using DryRun.
"""
from google.cloud import bigquery
from datetime import datetime
import json
import os

from src.services.bq_client import get_bigquery_client
from src.services.cost_utils import calculate_query_cost, format_bytes
from src.utils.logger import logger

class Estimate:
    def __init__(self, query, market):
        self.market = market
        self.query = query

    def estimate_query_cost(self):
        """
        Estimate the cost of a BigQuery SQL query without executing it.

        Args:
            query (str): SQL query to estimate

        Returns:
            dict: Cost estimate information
        """
        # Get BigQuery client
        client, project_id, dataset_id = get_bigquery_client(self.market)

        # Configure job for dry run
        job_config = bigquery.QueryJobConfig(
            dry_run=True,
            use_query_cache=False,
            default_dataset=f"{project_id}.{dataset_id}"
        )
        try:
            # Run the query as a dry run
            start_time = datetime.now()
            query_job = client.query(self.query, job_config=job_config)
            end_time = datetime.now()

            # Calculate elapsed time
            elapsed_ms = (end_time - start_time).total_seconds() * 1000

            # Get bytes that would be processed
            bytes_processed = query_job.total_bytes_processed or 0

            # Calculate cost
            cost_info = calculate_query_cost(bytes_processed)

            # Add additional information
            cost_info.update({
                'query': self.query,
                'elapsed_ms': elapsed_ms,
                'status': 'success',
                'timestamp': datetime.now().isoformat()
            })

            # Save to history file
            self.save_estimate_to_history(cost_info)
            return cost_info

        except Exception as e:
            # Handle errors
            return {
                'status': 'error',
                'error_message': str(e),
                'query': self.query,
                'timestamp': datetime.now().isoformat()
            }


    def compare_queries_cost(self, original_query, optimized_query):
        """
        Compare the cost of two queries (original and optimized).

        Args:
            original_query (str): Original SQL query
            optimized_query (str): Optimized SQL query

        Returns:
            dict: Comparison of cost estimates
        """
        # Estimate cost of original query
        original_estimate = Estimate.estimate_query_cost(original_query)

        # Estimate cost of optimized query
        optimized_estimate = Estimate.estimate_query_cost(optimized_query)

        # Calculate savings
        if original_estimate['status'] == 'success' and optimized_estimate['status'] == 'success':
            bytes_saved = original_estimate['bytes_processed'] - optimized_estimate['bytes_processed']
            cost_saved = original_estimate['estimated_cost_usd'] - optimized_estimate['estimated_cost_usd']

            # Calculate percentage saved
            if original_estimate['bytes_processed'] > 0:
                percentage_saved = (bytes_saved / original_estimate['bytes_processed']) * 100
            else:
                percentage_saved = 0

            return {
                'original_query': original_query,
                'original_cost': original_estimate,
                'optimized_query': optimized_query,
                'optimized_cost': optimized_estimate,
                'bytes_saved': bytes_saved,
                'formatted_bytes_saved': format_bytes(bytes_saved),
                'cost_saved_usd': round(cost_saved, 6),
                'percentage_saved': round(percentage_saved, 2),
                'status': 'success',
                'timestamp': datetime.now().isoformat()
            }
        else:
            # Handle case where one or both queries failed
            return {
                'original_query': original_query,
                'original_cost': original_estimate,
                'optimized_query': optimized_query,
                'optimized_cost': optimized_estimate,
                'status': 'error',
                'error_message': 'One or both queries failed to estimate cost',
                'timestamp': datetime.now().isoformat()
            }


    def get_query_execution_plan(self):
        """
        Get the execution plan for a query using EXPLAIN.

        Args:
            query (str): SQL query to analyze

        Returns:
            dict: Query execution plan and cost estimate
        """
        # Get BigQuery client
        client, project_id, dataset_id = get_bigquery_client()

        try:
            # Create EXPLAIN query
            explain_query = f"EXPLAIN PLAN FOR {self.query}"

            # Run the EXPLAIN query (this isn't a dry run)
            job_config = bigquery.QueryJobConfig(
                default_dataset=f"{project_id}.{dataset_id}"
            )
            explain_job = client.query(explain_query, job_config=job_config)
            explain_results = list(explain_job)

            # Also get the cost estimate
            estimate = Estimate.estimate_query_cost(self.query)

            # Combine results
            plan_info = {
                'query': self.query,
                'execution_plan': [dict(row) for row in explain_results],
                'cost_estimate': estimate,
                'status': 'success',
                'timestamp': datetime.now().isoformat()
            }

            return plan_info

        except Exception as e:
            return {
                'status': 'error',
                'error_message': str(e),
                'query': self.query,
                'timestamp': datetime.now().isoformat()
            }


    def save_estimate_to_history(self, estimate_data):
        """
        Save a cost estimate to the history file.

        Args:
            estimate_data (dict): Cost estimate data
        """
        history_file = 'cost_estimate_history.json'

        try:
            # Load existing history
            if os.path.exists(history_file):
                with open(history_file, 'r') as f:
                    try:
                        history = json.load(f)
                    except json.JSONDecodeError:
                        history = []
            else:
                history = []

            # Add new estimate
            history.append(estimate_data)

            # Save updated history
            with open(history_file, 'w') as f:
                json.dump(history, f, indent=2)

        except Exception as e:
            logger.error(f"Error saving estimate to history: {e}")


    def get_estimate_history(self, limit=10):
        """
        Get recent cost estimate history.

        Args:
            limit (int): Maximum number of history entries to return

        Returns:
            list: Recent cost estimate history
        """
        history_file = 'cost_estimate_history.json'

        try:
            # Load history
            if os.path.exists(history_file):
                with open(history_file, 'r') as f:
                    try:
                        history = json.load(f)
                    except json.JSONDecodeError:
                        history = []
            else:
                history = []

            # Sort by timestamp (newest first)
            history.sort(key=lambda x: x.get('timestamp', ''), reverse=True)

            # Limit results
            return history[:limit]

        except Exception as e:
            logger.error(f"Error getting estimate history: {e}")
            return []