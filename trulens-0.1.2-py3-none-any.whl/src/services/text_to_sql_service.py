from src.services.context_service import RelevantData
import json
from src.llm.prompt_templates import get_prompt_for_generating_sql_query
from src.llm.llm_connector import LLMConnector
from src.utils.logger import logger


class ConvertTextToSqlRequest():
    def __init__(self, query: str, llm_type: str, config):
        self.query = query
        self.llm_type = llm_type
        self.config = config

    def convert_text_to_sql_using_llm(self):
        logger.info("Generating SQL for: '%s'", self.query)
        if self.llm_type =='openai':
            # Get Table and columns contexts
            context = RelevantData(self.query, self.config)
            matched_tables = context.get_relevant_tables()
            matched_cols = context.get_relevant_columns()

            # Create prompt for text to sql
            # Define system instruction
            system_message = {
                "role": "system",
                "content": (
                    "You are a skilled Data Analyst with deep expertise in BigQuery and GoogleSQL dialect. "
                    "Your task is to generate accurate and optimized SQL queries only. "
                    "Respond strictly with the SQL query as per instructions—no explanations, comments, or additional text."
                )
            }
            # Load middle conversation from JSON
            MESSAGES_PATH = self.config.get('Database', 'messages_path')
            with open(MESSAGES_PATH, 'r') as file:
                middle_conversation = json.load(file)
            
            TEMPLATE = get_prompt_for_generating_sql_query(matched_tables, matched_cols, self.query)
            
            # Define the last user prompt dynamically
            last_prompt = {
                "role": "user",
                "content": f"{TEMPLATE}"
            }
            
            prompt_messages = [system_message] + middle_conversation + [last_prompt]

            llm = LLMConnector(prompt_messages, self.config)
            res = llm.get_llm_response()
            logger.debug("LLM response: %s", res)
            if "Optimised Query:-" in res:
                return res.split("Optimised Query:-")[1]
            elif "Optimised Query:" in res:
                return res.split("Optimised Query:")[1]
            else:
                return res
        else:
            return f"Unsupported LLM: {self.llm_type}"
