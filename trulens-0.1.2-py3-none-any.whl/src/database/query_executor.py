from src.services.bq_client import get_bigquery_client
from google.cloud import bigquery
from google.api_core.exceptions import BadRequest, GoogleAPIError

def execute(sql_query: str, market: str) -> list:
    try:
            client, project_id, dataset_id = get_bigquery_client(market)

            job_config = bigquery.QueryJobConfig(
                dry_run=False, 
                use_query_cache=False,
                default_dataset=f"{project_id}.{dataset_id}"
            )

            query_job = client.query(sql_query, job_config=job_config)
            results = query_job.result()

            return [dict(row) for row in results]

    except BadRequest as e:
        raise Exception(f"BadRequest in BigQuery execution: {e.message}")
    except GoogleAPIError as e:
        raise Exception(f"GoogleAPIError: {str(e)}")
    except Exception as e:
        raise Exception(f"Unexpected error during query execution: {str(e)}")