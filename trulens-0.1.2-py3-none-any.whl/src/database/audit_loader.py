from typing import Tuple, Optional, Dict, Any
from src.database.postgres_loader import PostgresLoader
from src.utils.hash_audit import compute_md5_hash

def handle_generic_audit(
    pg: PostgresLoader,
    cur,
    user_id: str,
    user_name: str,
    old_data: Dict[str, Any],
    new_data: Dict[str, Any],
    entity_name: str,
    entity_id: str
):
    action, old_changes, new_changes, metadata = determine_audit_action(old_data, new_data)
    
    if action:
        pg.insert_audit_log(
            cur=cur,
            user_id=user_id,
            user_name=user_name,
            action=action,
            entity_name=entity_name,
            entity_id=entity_id,
            old_data=old_changes,
            new_data=new_changes,
            metadata=metadata
        )

def get_table_audit_data(cur, id_key: str):
    cur.execute("SELECT * FROM table_config WHERE id_key = %s", (id_key,))
    columns = [desc[0] for desc in cur.description]
    row = cur.fetchone()
    return dict(zip(columns, row)) if row else {}

def get_column_audit_data(cur, id_key: str):
    cur.execute("SELECT * FROM column_config WHERE id_key = %s", (id_key,))
    columns = [desc[0] for desc in cur.description]
    row = cur.fetchone()
    return dict(zip(columns, row)) if row else {}

def determine_audit_action(old_data: dict, new_data: dict) -> Tuple[Optional[str], Dict[str, Any], Dict[str, Any], dict]:
    if not old_data:
        return None, {}, {}, {}

    old_hash = compute_md5_hash(old_data)
    new_hash = compute_md5_hash(new_data)

    if old_hash != new_hash:
        action = "DELETE" if all(v is None for v in new_data.values()) else "UPDATE"
        changed_fields = {
            k: {"old": old_data.get(k), "new": new_data.get(k)}
            for k in new_data
            if old_data.get(k) != new_data.get(k)
        }
        old_changes = {k: v["old"] for k, v in changed_fields.items()}
        new_changes = {k: v["new"] for k, v in changed_fields.items()}
        return action, old_changes, new_changes, {}

    return None, {}, {}, {}