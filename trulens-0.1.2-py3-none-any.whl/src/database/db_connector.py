from src.utils.config_reader import load_config

def get_postgres_connection_params(marketname):
    config = load_config(marketname)

    PG_HOST = config['POSTGRES']['host']
    PG_PORT = config['POSTGRES']['port']
    PG_DATABASE = config['POSTGRES']['database']
    PG_USER = config['POSTGRES']['user']
    PG_PASSWORD = config['POSTGRES']['password']

    return PG_HOST, PG_PORT, PG_DATABASE, PG_USER, PG_PASSWORD