import psycopg2
from psycopg2 import sql
import json
from datetime import datetime

from src.database.db_connector import get_postgres_connection_params


def validate_required_fields(metadata, required_fields, object_type="record"):
    for field in required_fields:
        if field not in metadata:
            raise ValueError(f"Missing required field '{field}' in {object_type}")
        if metadata[field] is None:
            raise ValueError(f"Required field '{field}' cannot be None in {object_type}")

def generate_id_key(data_source_id, data_namespace, table_name_details):
    namespace = data_namespace if data_namespace and data_namespace.strip() else "NA"
    return f"{data_source_id}~{namespace}~{table_name_details}"

def generate_column_id_key(data_source_id, data_namespace, table_name_details, column_name_details):
    namespace = data_namespace if data_namespace and data_namespace.strip() else "NA"
    return f"{data_source_id}~{namespace}~{table_name_details}~{column_name_details}"


class PostgresLoader:
    def __init__(self, market):
        self.market = market
        self.host, self.port, self.database, self.user, self.password = get_postgres_connection_params(self.market)

    def create_table_config(self):
        create_table_config_sql = """
        CREATE TABLE IF NOT EXISTS table_config (
        id_key VARCHAR(200) PRIMARY KEY,
        data_source_id VARCHAR(100) NOT NULL,
        table_name_details VARCHAR(100) NOT NULL,
        display_name VARCHAR(100) NOT NULL,
        data_namespace VARCHAR(100),
        description TEXT,
        filter_columns TEXT[],
        aggregate_columns TEXT[],
        sort_columns TEXT[],
        key_columns TEXT[],
        join_tables JSONB,  
        related_business_terms TEXT[],
        sample_usage JSONB,
        tags TEXT[],
        created_at TIMESTAMP,
        updated_at TIMESTAMP,
        created_by VARCHAR(100),
        updated_by VARCHAR(100),
        CONSTRAINT table_config_table_name_key UNIQUE (data_source_id, table_name_details)
        );
        """

        conn = None
        try:
            conn = psycopg2.connect(
                host=self.host,
                port=self.port,
                dbname=self.database,
                user=self.user,
                password=self.password
            )
            cur = conn.cursor()
            cur.execute(create_table_config_sql)
            conn.commit()
            cur.close()
        except Exception as e:
            raise
        finally:
            if conn:
                conn.close()

    def create_column_config(self):
        create_column_config_sql = """
        CREATE TABLE IF NOT EXISTS column_config (
        id_key VARCHAR(200) PRIMARY KEY,
        data_source_id VARCHAR(100) NOT NULL,
        table_name_details VARCHAR(100) NOT NULL,
        column_name_details VARCHAR(100) NOT NULL,
        data_namespace VARCHAR(100),
        description TEXT,
        data_type VARCHAR(20) NOT NULL,
        is_filterable BOOLEAN DEFAULT FALSE,
        is_aggregatable BOOLEAN DEFAULT FALSE,
        sample_values TEXT[],
        related_business_terms TEXT[],
        sample_usage JSONB,
        created_at TIMESTAMP,
        updated_at TIMESTAMP,
        created_by VARCHAR(100),
        updated_by VARCHAR(100),
        CONSTRAINT unique_table_column UNIQUE (data_source_id, table_name_details, column_name_details)
        );
        """

        conn = None
        try:
            conn = psycopg2.connect(
                host=self.host,
                port=self.port,
                dbname=self.database,
                user=self.user,
                password=self.password
            )
            cur = conn.cursor()
            cur.execute(create_column_config_sql)
            conn.commit()
            cur.close()
        except Exception as e:
            raise
        finally:
            if conn:
                conn.close()
    
    def create_audit_logs(self):
        create_audit = """
        CREATE TABLE IF NOT EXISTS audit_logs (
        id BIGSERIAL PRIMARY KEY,
        
        user_id TEXT,
        user_name TEXT,
        
        action TEXT NOT NULL,
        entity_name TEXT NOT NULL,
        entity_id TEXT NOT NULL,
        
        event_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        
        old_data JSONB, 
        new_data JSONB, 
        
        metadata JSONB
        );
        """

        conn = None
        try:
            conn = psycopg2.connect(
                host=self.host,
                port=self.port,
                dbname=self.database,
                user=self.user,
                password=self.password
            )
            cur = conn.cursor()
            cur.execute(create_audit)
            conn.commit()
            cur.close()
        except Exception as e:
            raise
        finally:
            if conn:
                conn.close()

    def insert_table_metadata(self, metadata, table_name="table_config"):
        conn = None
        try:
            required_fields = ['data_source_id', 'table_name', 'display_name']
            validate_required_fields(metadata, required_fields, object_type="table metadata")
            conn = psycopg2.connect(
                host=self.host,
                port=self.port,
                dbname=self.database,
                user=self.user,
                password=self.password
            )
            cur = conn.cursor()

            created_at = datetime.utcnow()
            updated_at = datetime.utcnow()
            
            id_key = generate_id_key(metadata.get("data_source_id"), metadata.get('data_namespace', ''), metadata['table_name'])
            join_tables_data = json.dumps(metadata.get('join_tables', []))
            sample_usage_data = json.dumps(metadata.get('sample_usage', []))
            insert_sql = sql.SQL("""
                INSERT INTO {table} (
                    id_key, data_source_id, table_name_details, display_name, data_namespace, description,
                    filter_columns, aggregate_columns, sort_columns, key_columns, join_tables,
                    related_business_terms, sample_usage, tags, created_at, updated_at,
                    created_by, updated_by
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s, %s::jsonb, %s, %s, %s, %s, %s)
                ON CONFLICT (id_key) DO UPDATE SET
                    display_name = EXCLUDED.display_name,
                    description = EXCLUDED.description,
                    filter_columns = EXCLUDED.filter_columns,
                    aggregate_columns = EXCLUDED.aggregate_columns,
                    sort_columns = EXCLUDED.sort_columns,
                    key_columns = EXCLUDED.key_columns,
                    join_tables = EXCLUDED.join_tables,
                    related_business_terms = EXCLUDED.related_business_terms,
                    sample_usage = EXCLUDED.sample_usage,
                    tags = EXCLUDED.tags,
                    updated_by = EXCLUDED.updated_by,
                    updated_at = EXCLUDED.updated_at
                RETURNING id_key;
            """).format(table=sql.Identifier(table_name))

            cur.execute(insert_sql, (
                id_key,
                metadata.get("data_source_id"),
                metadata['table_name'],
                metadata['display_name'],
                metadata.get('data_namespace', None),
                metadata.get('description', None),
                metadata.get('filter_columns', []),
                metadata.get('aggregate_columns', []),
                metadata.get('sort_columns', []),
                metadata.get('key_columns', []),
                join_tables_data,
                metadata.get('related_business_terms', []),
                sample_usage_data,
                metadata.get('tags', []),
                created_at,
                updated_at,
                metadata.get('created_by', 'admin'),
                metadata.get('updated_by', 'admin')
            ))

            inserted_id = cur.fetchone()[0]
            conn.commit()
            cur.close()
            return inserted_id

        except Exception as e:
            raise
        finally:
            if conn:
                conn.close()

    def insert_column_metadata(self, metadata, table_name="column_config"):
        conn = None
        try:
            required_fields = ['data_source_id', 'table_name', 'column_name', 'data_type']
            validate_required_fields(metadata, required_fields, object_type="column metadata")
            conn = psycopg2.connect(
                host=self.host,
                port=self.port,
                dbname=self.database,
                user=self.user,
                password=self.password
            )
            cur = conn.cursor()

            created_at = datetime.utcnow()
            updated_at = datetime.utcnow()
            
            id_key = generate_column_id_key(
                metadata.get("data_source_id"),
                metadata.get('data_namespace', ''),
                metadata['table_name'],
                metadata['column_name']
            )
            sample_usage_data = json.dumps(metadata.get('sample_usage', []))

            insert_sql = sql.SQL("""
                INSERT INTO {table} (id_key, data_source_id, table_name_details, column_name_details, data_namespace,
                                    description, data_type, is_filterable, is_aggregatable, sample_values, related_business_terms,
                                    sample_usage, created_at, updated_at, created_by, updated_by)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s::jsonb, %s, %s, %s, %s)
                ON CONFLICT (id_key) DO UPDATE SET
                description = EXCLUDED.description,
                data_type = EXCLUDED.data_type,
                is_filterable = EXCLUDED.is_filterable,
                is_aggregatable = EXCLUDED.is_aggregatable,
                sample_values = EXCLUDED.sample_values,
                related_business_terms = EXCLUDED.related_business_terms,
                sample_usage = EXCLUDED.sample_usage,
                updated_by = EXCLUDED.updated_by,
                updated_at = EXCLUDED.updated_at
                RETURNING id_key;
            """).format(table=sql.Identifier(table_name))

            cur.execute(insert_sql, (
                id_key,
                metadata.get("data_source_id"),
                metadata['table_name'],
                metadata['column_name'],
                metadata.get('data_namespace', None),
                metadata.get('description', None),
                metadata['data_type'],
                metadata.get('is_filterable', False),
                metadata.get('is_aggregatable', False),
                metadata.get('sample_values', []),
                metadata.get('related_business_terms', []),
                sample_usage_data,
                created_at,
                updated_at,
                metadata.get('created_by', 'admin'),
                metadata.get('updated_by', 'admin')
            ))

            inserted_id = cur.fetchone()[0]
            conn.commit()
            cur.close()
            return inserted_id

        except Exception as e:
            raise
        finally:
            if conn:
                conn.close()

    def insert_audit_log(self, cur, user_id: str, user_name: str, 
                       action: str, entity_name: str, entity_id: str,
                       old_data: dict, new_data: dict, metadata: dict):
        """Universal audit log insertion"""
        audit_sql = """
            INSERT INTO audit_logs (
                user_id, user_name, action, entity_name, entity_id,
                event_time, old_data, new_data, metadata
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        cur.execute(audit_sql, (
            user_id,
            user_name,
            action,
            entity_name,
            entity_id,
            datetime.utcnow(),
            json.dumps(old_data) if old_data else None,
            json.dumps(new_data) if new_data else None,
            json.dumps(metadata)
        ))