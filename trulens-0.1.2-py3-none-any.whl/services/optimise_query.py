from src.services.context_service import RelevantData
import json
from src.llm.prompt_templates import get_prompt_for_optimised_query
from src.llm.llm_connector import LLMConnector
from src.utils.logger import logger


class OptimiseQuery():
    def __init__(self, query: str, llm_type: str, config):
        self.query = query
        self.llm_type = llm_type
        self.config = config

    def optimise_query(self):
        logger.info("Optimising SQL for: '%s'", self.query)
        if self.llm_type =='openai':
            # Get Table and columns contexts
            context = RelevantData(self.query, self.config)
            matched_tables = context.get_relevant_tables()
            matched_cols = context.get_relevant_columns()

            # Create prompt for text to sql
            # Define system instruction
            system_message = {
                "role": "system",
                "content": (
                    "You are a BigQuery optimization expert with deep knowledge of query performance tuning and the GoogleSQL dialect. "
                    "Your specialty is analyzing SQL queries and restructuring them for maximum efficiency while preserving identical functionality and output. "
                    "Focus on: reducing query cost, minimizing data processed, optimizing join operations, leveraging appropriate indexes, "
                    "and applying BigQuery-specific best practices for large-scale data processing. "
                    "Respond ONLY with the optimized SQL query exactly as instructed in the format 'Optimised Query:-[query]'. "
                    "Include no explanations, comments, or additional text in your response."
                )
            }
            # Load middle conversation from JSON
            # MESSAGES_PATH = self.config.get('Database', 'messages_path')
            # with open(MESSAGES_PATH, 'r') as file:
            #     middle_conversation = json.load(file)

            application_prompt = get_prompt_for_optimised_query(matched_tables, matched_cols, self.query)

            # Define the last user prompt dynamically
            last_prompt = {
                "role": "user",
                "content": f"{application_prompt}"
            }

            prompt_messages = [system_message]  + [last_prompt]

            llm = LLMConnector(prompt_messages, self.config)
            res = llm.get_llm_response()
            logger.debug("LLM response: %s", res)
            if "Optimised Query:-" in res:
                return res.split("Optimised Query:-")[1]
            elif "Optimised Query:" in res:
                return res.split("Optimised Query:")[1]
            else:
                return res
        else:
            return f"Unsupported LLM: {self.llm_type}"
