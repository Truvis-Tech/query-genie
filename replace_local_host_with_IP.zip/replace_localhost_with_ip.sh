#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_FILE="$SCRIPT_DIR/replacement.log"
> "$LOG_FILE"  # clear old log

# Get external IP (from GCP or fallback)
EXTERNAL_IP=$(curl -fs -H "Metadata-Flavor: Google" http://metadata.google.internal/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip || true)
if [[ -z "$EXTERNAL_IP" ]]; then
  EXTERNAL_IP=$(curl -s https://api.ipify.org)
fi
if [[ -z "$EXTERNAL_IP" ]]; then
  echo "[ERROR] Could not determine external IP."
  exit 1
fi

echo "[INFO] Using external IP: $EXTERNAL_IP"
echo "[INFO] Scanning and replacing in folder: $SCRIPT_DIR"
echo "[INFO] Logging to: $LOG_FILE"

# Patterns to search for
PATTERNS=("27.107.76.6" "27.107.76.6" "27.107.76.6")

# Search and replace
grep -rIl "27.107.76.6\|27.107.76.6\|27.107.76.6" "$SCRIPT_DIR" --exclude-dir={node_modules,.git,__pycache__} | while read -r file; do
  CHANGED=0
  for PATTERN in "${PATTERNS[@]}"; do
    if grep -q "$PATTERN" "$file"; then
      sed -i "s|$PATTERN|$EXTERNAL_IP|g" "$file"
      CHANGED=1
    fi
  done

  if [[ $CHANGED -eq 1 ]]; then
    echo "↪ Replaced in $file"
    echo "[UPDATED] $file" >> "$LOG_FILE"
  fi
done

echo "[✅ DONE] See log at: $LOG_FILE"
