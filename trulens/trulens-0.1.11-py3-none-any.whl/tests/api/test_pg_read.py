import pytest
from fastapi.testclient import TestClient
from run import app
import os

os.environ["TEST_MODE"] = "true"

@pytest.fixture
def client():
    client = TestClient(app)
    return client

def test_get_metadata():
    assert True

def test_get_recommendations(client):
    payload = {
        "market": "US"
    }
    response = client.post("/get-recommendations", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.status_code == 200
        assert "data" in response.json()
        # Check that the mock data structure is as expected
        data = response.json()["data"]
        assert isinstance(data, list)
        if len(data) > 0:
            assert "rule_id" in data[0]
            assert "no_of_queries" in data[0]
            assert "total_queries" in data[0]
            assert "sample_query" in data[0]
            assert "no_of_schemas" in data[0]
            assert "recommendation" in data[0]
    else:
        assert response.status_code in [200, 500]
        if response.status_code == 200:
            assert "data" in response.json()

def test_get_total_schemas(client):
    payload = {
        "market": "US"
    }
    response = client.post("/get-total-schemas", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.status_code == 200
        assert "data" in response.json()
        assert "total_schemas" in response.json()["data"]
        # Verify the data type is numeric (int or float)
        total_schemas = response.json()["data"]["total_schemas"]
        assert isinstance(total_schemas, (int, float))
    else:
        assert response.status_code in [200, 500]
        if response.status_code == 200:
            assert "data" in response.json()
            assert "total_schemas" in response.json()["data"]

def test_get_total_queries(client):
    payload = {
        "market": "US"
    }
    response = client.post("/get-total-queries", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.status_code == 200
        assert "data" in response.json()
        assert "total_queries" in response.json()["data"]
        # Verify the data type is numeric (int or float)
        total_queries = response.json()["data"]["total_queries"]
        assert isinstance(total_queries, (int, float))
    else:
        assert response.status_code in [200, 500]
        if response.status_code == 200:
            assert "data" in response.json()
            assert "total_queries" in response.json()["data"]

def test_get_total_query_scanned(client):
    payload = {
        "market": "US"
    }
    response = client.post("/get-total-query-scanned", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.status_code == 200
        assert "data" in response.json()
        assert "total_query_scanned" in response.json()["data"]
        # Verify the data type is numeric (int or float)
        total_query_scanned = response.json()["data"]["total_query_scanned"]
        assert isinstance(total_query_scanned, (int, float))
    else:
        assert response.status_code in [200, 500]
        if response.status_code == 200:
            assert "data" in response.json()
            assert "total_query_scanned" in response.json()["data"]
