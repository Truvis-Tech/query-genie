import pytest
from fastapi.testclient import TestClient
from run import app
import os

os.environ["TEST_MODE"] = "true"



@pytest.fixture
def client():
    client = TestClient(app)
    return client

def test_health_endpoint(client):
    response = client.get('/health')
    assert response.status_code == 200

def test_generate_query_endpoint(client):
    payload = {
        "query": "Show the currency distribution of transaction origins based on payment types from event store only, by grouping the data on currency and payment type",
        "llm_type": "openai", 
        "market": "US"
    }
    response = client.post("/generate_query", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 500]
        assert "sql_query_generated" in response.json()

def test_estimate(client):
    payload = {
        "query": "SELECT customer_email_last_update_at FROM event_store WHERE vulk_id = 'BULK_123456'",
        "market": "US"
    }
    response = client.post("/estimate", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 500]
    

def test_execute_query_endpoint(client):
    payload = {
        "query": "SELECT customer_email_last_update_at FROM event_store WHERE customer_id = '12345'",
        "market": "US"
    }
    response = client.post("/execute_query", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 400]

def test_postgres_loader_invalid_type(client):
    payload = {
        "metadata_type": "column",
        "market": "US"
    }
    response = client.post("/postgres_loader/", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 400, 500]

def test_get_tables_bq(client):
    payload = {
        "market": "US"
    }
    response = client.post("/get-tables", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 400]
        if response.status_code == 200:
            assert "result" in response.json()

def test_get_columns_bq(client):
    payload = {
        "market": "US",
        "table_name": "event_store"
    }
    response = client.post("/get-columns", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 500]
        if response.status_code == 200:
            assert "result" in response.json()

def test_get_table_metadata_pg(client):
    payload = {
        "market": "US",
        "table_name": "event_store"
    }
    response = client.post("/get-table-metadata", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 404, 400]
        if response.status_code == 200:
            assert "result" in response.json()

def test_get_column_metadata_pg(client):
    payload = {
        "market": "US",
        "table_name": "event_store",
        "column_name": "sender_transaction_currency"
    }
    response = client.post("/get-column-metadata", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 404, 400]
        if response.status_code == 200:
            assert "result" in response.json()
            
def test_pg_vector_loader_table(client):
    payload = {
        "metadata_type": "table",
        "market": "US"
    }
    response = client.post("/pg_vector_loader", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 500]
        if response.status_code == 200:
            assert "status" in response.json()
            assert response.json()["status"] == "success"
            
def test_pg_vector_loader_column(client):
    payload = {
        "metadata_type": "column",
        "market": "US"
    }
    response = client.post("/pg_vector_loader", json=payload)
    if os.getenv("TEST_MODE") == "true":
        assert response.json() == {"message": "Mocked response in test mode"}
    else:
        assert response.status_code in [200, 500]
        if response.status_code == 200:
            assert "status" in response.json()
            assert response.json()["status"] == "success"