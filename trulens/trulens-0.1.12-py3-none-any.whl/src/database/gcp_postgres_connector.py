"""
GCP Cloud SQL Postgres connector using IAM authentication.
This module provides functionality to connect to a GCP Cloud SQL Postgres instance
using IAM authentication with service accounts instead of passwords.
"""

import os
import json
from typing import Dict, Any, Optional
import time

import sqlalchemy
from sqlalchemy import create_engine
from google.auth import default, impersonated_credentials
from google.auth.transport.requests import Request
import pg8000

from src.utils.config_reader import load_config


class GCPPostgresConnector:
    """
    A connector for GCP Cloud SQL Postgres instances using IAM authentication.
    Uses service account credentials and IAM database authentication instead of passwords.
    """

    def __init__(self, marketname: str):
        """
        Initialize the connector with configuration from the specified market.
        
        Args:
            marketname: The market name to load configuration for (e.g., 'US')
        """
        self.config = load_config(marketname)
        self.project_id = self.config['POSTGRES']['project_id']
        self.instance_id = self.config['POSTGRES']['instance_id']
        self.database = self.config['POSTGRES']['database']
        self.region = self.config['POSTGRES']['region']
        self.user = self.config['POSTGRES']['user']
        self.service_account_path = self.config.get('POSTGRES', 'service_account_path', fallback=None)
        
        # Optional IAM service account impersonation
        self.impersonate_account = self.config.get('POSTGRES', 'impersonate_account', fallback=None)
        
        # Connection pool settings
        self.pool_size = int(self.config.get('POSTGRES', 'pool_size', fallback=5))
        self.max_overflow = int(self.config.get('POSTGRES', 'max_overflow', fallback=10))
        self.pool_timeout = int(self.config.get('POSTGRES', 'pool_timeout', fallback=30))
        self.pool_recycle = int(self.config.get('POSTGRES', 'pool_recycle', fallback=1800))
        
        # Connection cache
        self._engine = None

    def _get_credentials(self):
        """
        Get the appropriate credentials for IAM authentication.
        
        Returns:
            Google auth credentials object
        """
        if self.service_account_path:
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = self.service_account_path
            
        credentials, project = default()
        
        # If impersonation is configured, create impersonated credentials
        if self.impersonate_account:
            credentials = impersonated_credentials.Credentials(
                source_credentials=credentials,
                target_principal=self.impersonate_account,
                target_scopes=['https://www.googleapis.com/auth/cloud-platform'],
                lifetime=3600  # 1 hour
            )
            
        # Ensure credentials are fresh
        if not credentials.valid:
            credentials.refresh(Request())
            
        return credentials

    def _get_iam_auth_token(self):
        """
        Get an IAM authentication token for Cloud SQL.
        
        Returns:
            str: The IAM authentication token
        """
        credentials = self._get_credentials()
        
        # Request an OAuth 2.0 access token for the Cloud SQL Admin API
        credentials.refresh(Request())
        
        # Return the access token
        return credentials.token

    def get_connection_string(self):
        """
        Build the connection string for the Cloud SQL instance.
        
        Returns:
            str: SQLAlchemy connection string
        """
        # Get IAM token for authentication
        token = self._get_iam_auth_token()
        
        # Configure pg8000 to use IAM authentication
        def pg8000_connect(**kwargs):
            # Remove parameters that pg8000 doesn't accept
            kwargs.pop('driver', None)
            
            # Add IAM token as password
            kwargs['password'] = token
            
            # Connect using the Cloud SQL instance connection name
            connection_name = f"{self.project_id}:{self.region}:{self.instance_id}"
            
            # Use the Cloud SQL Proxy socket factory for connection
            return pg8000.connect(
                user=self.user,
                database=self.database,
                unix_sock=f"/cloudsql/{connection_name}/.s.PGSQL.5432",
                **kwargs
            )
        
        # Register the pg8000 dialect with our custom connect function
        sqlalchemy.dialects.postgresql.pg8000.dbapi = lambda: pg8000
        
        # Create the connection string
        connection_string = f"postgresql+pg8000://{self.user}@/{self.database}"
        
        # Add query parameters for Cloud SQL connection
        query_params = {
            "unix_sock": f"/cloudsql/{self.project_id}:{self.region}:{self.instance_id}/.s.PGSQL.5432"
        }
        
        # Add query parameters to connection string
        connection_string += "?" + "&".join([f"{k}={v}" for k, v in query_params.items()])
        
        return connection_string

    def get_engine(self):
        """
        Get a SQLAlchemy engine for the Cloud SQL instance.
        
        Returns:
            sqlalchemy.engine.Engine: SQLAlchemy engine
        """
        if self._engine is None:
            connection_string = self.get_connection_string()
            
            # Create the engine with connection pooling
            self._engine = create_engine(
                connection_string,
                pool_size=self.pool_size,
                max_overflow=self.max_overflow,
                pool_timeout=self.pool_timeout,
                pool_recycle=self.pool_recycle,
                connect_args={"application_name": "trulens"}
            )
            
        return self._engine

    def execute_query(self, query: str, params: Optional[Dict[str, Any]] = None):
        """
        Execute a SQL query and return the results.
        
        Args:
            query: SQL query to execute
            params: Parameters for the query
            
        Returns:
            List of dictionaries containing the query results
        """
        engine = self.get_engine()
        with engine.connect() as connection:
            result = connection.execute(sqlalchemy.text(query), params or {})
            return [dict(row) for row in result]

    def test_connection(self):
        """
        Test the connection to the Cloud SQL instance.
        
        Returns:
            bool: True if connection is successful
        """
        try:
            self.execute_query("SELECT 1")
            return True
        except Exception as e:
            print(f"Connection test failed: {e}")
            return False
